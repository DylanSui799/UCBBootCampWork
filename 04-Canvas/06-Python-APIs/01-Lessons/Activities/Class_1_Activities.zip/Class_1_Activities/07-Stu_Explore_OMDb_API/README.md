# OMDb API

In this activity, you’ll review the OMDb API documentation, and you’ll practice using the API.

## Instructions

Read the OMDb [documentation](http://www.omdbapi.com/), and make a few API calls to get some information about your favorite movie.

- - -

© 2022 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.