# Geoapify API Key
geoapify_key = "YOUR KEY HERE"
